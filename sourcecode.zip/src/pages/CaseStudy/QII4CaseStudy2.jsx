import React, { useEffect } from "react";
import Header3 from "../../components/Header3";
import ListImageText from "../../components/ListImageText";
import "../QII2CaseStudy.css";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setBradcrump } from "../../slices/appDataSlice";
import { useLocation} from "react-router-dom";


export default function QII4CaseStudy2() {
  const location = useLocation();

  useEffect(() => {
      setTimeout(() => {
        if (location.state?.scrollTo) {
          const el = document.getElementById(location.state.scrollTo);
          el?.scrollIntoView({ behavior: "smooth" });
          navigate(location.pathname, { replace: true, state: null });
        }
      }, 500);
    }, [location]);


  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      setBradcrump({
        show: true,
        dir: [
          { path: "/qii4", title: "QII.4 Resilience" },
          { path: "/qii4", title: "Case Study" },
        ],
      }),
    );
  }, []); 
  return (
    <div className="single-case-study-page" id="qii4CS2">
      <section className="color-light">
        <div className="container">
          <div className="single-case-study-wrapper"style={{
              backgroundImage: `linear-gradient(0deg, rgba(0, 0, 0, 0) 60%, rgba(0, 0, 0, 0.6) 85%, rgba(0, 0, 0, 0.8) 100% ), url("images/qii4/updated/Shibaura_Wastewater_Management.png")`,
            }}>
            <h2 className="main-title main-title-internal">
              <p>Japan</p>
              <span>Shibaura Wastewater Treatment Facility:</span> Financing
              Resilience through Land Value Capture
            </h2>
            <div className="sub-title">
              <h2>CASE SNAPSHOT</h2>
            </div>
            <div className="case-study-details">
              <div className="case-study-details-card">
                <div className="icon-title">
                  <img src="images/qii2/case-study/sector_icon.svg" alt="" />
                  <h3>SECTOR</h3>
                  <p>Urban Flood & Wastewater Management</p>
                </div>
              </div>
              <div className="case-study-details-card">
                <div className="icon-title">
                  <img src="images/qii2/case-study/country_icon.svg" alt="" />
                  <h3>COUNTRY</h3>
                  <p>
                    Japan
                    <br />
                    <br />
                    <br />
                    <br />
                  </p>
                </div>
              </div>
              <div className="case-study-details-card">
                <div className="icon-title">
                  <img src="images/qii2/case-study/timeline.svg" alt="" />
                  <h3>TIMELINE</h3>
                  <p>
                    2004-2013
                    <br />
                    <br />
                    <br />
                    <br />
                  </p>
                </div>
              </div>
              <div className="case-study-details-card">
                <div className="icon-title">
                  <img src="images/qii2/case-study/cost_icon.svg" alt="" />
                  <h3>COST</h3>
                  <p>
                    ¥34.1 billion (US$310 million) - for Phase 1 improvements
                    <br />
                    <br />
                    <br />
                  </p>
                </div>
              </div>
              <div className="case-study-details-card">
                <div className="icon-title">
                  <img src="images/qii2/case-study/result_icon.svg" alt="" />
                  <h3>RESULT</h3>
                  <div>
                    <ul>
                      <li>
                        Expansion of 135,000 m<sup>3</sup> underground stormwater storage
                        capacity, protecting a high-density urban bay area from
                        flooding
                      </li>
                      <li>
                        A Public Private Partnership (PPP) using land value
                        capture financed above ground commercial facilities,
                        creating sustainable revenues to support operations and
                        maintenance
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="single-case-study-buttons">
            <div
              className="single-case-study-button"
              onClick={() => window.open(
                "pdf/QII_4_Case Japan Urban Resilience 2.pdf", 
                "_blank", 
                "noopener,noreferrer"
              )}
            >
              View case study summary
              <div className="arrow-btn icon-arrow">&#xe900;</div>
            </div>
            <div
              className="single-case-study-button"
              onClick={() =>
                window.open(
                  "https://documents1.worldbank.org/curated/en/915131601460271575/pdf/Appendix-Case-Studies-in-Integrated-Urban-Flood-Risk-Management-in-Japan.pdf#page=44",
                  "_blank",
                  "noopener,noreferrer",
                )
              }
            >
              Full Publication​
              <div className="arrow-btn icon-arrow">&#xe900;</div>
            </div>
            {/* <div
              className="single-case-study-button"
              onClick={() =>
                window.open(
                  "pdf/Fukuoka_city_case_study.pdf",
                  "_blank",
                  "noopener,noreferrer",
                )
              }
            >
              View data
              <div className="arrow-btn icon-arrow">&#xe900;</div>
            </div> */}
          </div>
        </div>
      </section>
    </div>
  );
}
