import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { principles, setBradcrump } from "../slices/appDataSlice";
import "./Home.css";
import ResourceLibrary from "./ResourceLibrary";
import FAQ from "../components/FAQ";
import { Link, useLocation, useNavigate } from "react-router-dom";
export default function Home() {
  const principleArray = useSelector(principles);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    dispatch(setBradcrump({ show: false, dir: [] }));
  }, []);

  const [preSelectedResources, setPreSelectedResources] = useState([]);

  useEffect(() => {
    setTimeout(() => {
      if (location.state?.resourceCategory) {
        setPreSelectedResources([location.state?.resourceCategory]);
        const el = document.getElementById(location.state.scrollTo);
        el?.scrollIntoView({ behavior: "smooth" });
        navigate("/", { replace: true, state: null });
      } else if (location.state?.scrollTo) {
        const el = document.getElementById(location.state.scrollTo);
        el?.scrollIntoView({ behavior: "smooth" });
        navigate("/", { replace: true, state: null });
      }
    }, 500);
  }, [location]);

  return (
    <div className="home color-light">
      <section className="landing_page" id="qii-sec1">
        <div className="circle-bg">
          <img src="images/circle_right.png" />
        </div>
        <img className="landing_page_bg" src="images/landing_image.jpg" />
        <div className="container">
          <div className="content_left">
            <h1>
              <strong>
                How Can We Help You Build Quality Infrastructure Today?
              </strong>
            </h1>
            <p className="light-font ">
              Explore tools, principles, and resources to apply Quality
              Infrastructure Investment (QII) Principles to your projects.
            </p>
          </div>
          <img src="images/Scroll_icon.png" className="scroll-icon" alt="" />
        </div>
        <div></div>
      </section>
      <section className="color-dark  principles-page" id="qii-sec2">
        <div className="circle-bg">
          <img src="images/circle_left.png" />
        </div>
        <div className="container">
          <h2 className="section-title light-font">
            Explore The QII Principles
          </h2>
          <div className="principles-grid" id="principles-grid" role="list">
            {principleArray.map((p, index) => (
              <article
                className="principle-card"
                key={index}
                role="listitem"
                style={{ backgroundImage: `url(${p.img})` }}
              >
                {" "}
                <Link to={p.path}>
                  <div className="card-link">
                    <div className="card-overlay" />

                    <div className="card-body">
                      <img src={p.img_path} alt={p.title} />
                    </div>

                    <div className="card-arrow">
                      <span className="icon-arrow">&#xe900;</span>
                    </div>
                  </div>
                </Link>
              </article>
            ))}
          </div>
          <button
            className="btn-arrow-txt"
            id="priciple-sections"
            onClick={() => navigate("/fundamentals_of_qii")}
          >
            Explore the Fundamentals Of QII{" "}
            <span className="icon-arrow"></span>
          </button>
        </div>
      </section>
      <section className="color-light z-2" id="all_principle_page">
        <ResourceLibrary preSelected={preSelectedResources}></ResourceLibrary>
      </section>
      <section className="color-dark faq_page" id="faq_page">
        <div className="circle-bg">
          <img src="images/circle_right.png" />
        </div>
        <FAQ></FAQ>
      </section>
    </div>
  );
}
