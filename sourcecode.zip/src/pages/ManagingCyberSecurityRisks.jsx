import React, { useEffect } from "react";
import "./ManagingCyberSecurityRisks.css";
import "./ResilientDesignAndOperation.css";
import NumSteps from "../components/NUmSteps";
import VCard from "../components/VCard";
import HeaderCarousal from "../components/HeaderCarousal";
import Header3 from "../components/Header3";
import { useDispatch } from "react-redux";
import { setBradcrump } from "../slices/appDataSlice";
import ResourceLibrary from "./ResourceLibrary";
import VCardsPagination from "../components/VCardsPagination";
import { useLocation } from "react-router-dom";

export default function ManagingCyberSecurityRisks() {
  const location = useLocation();
  const STEP1_PAGE_SIZE = 3;
  const step1Cards = [
    {
      rId: 113,
      image:
        "images/qii4/ManagingCyberSecurityRisks/Ghana A case study in strengthening cyber resilience (World Bank).png",
      title: (
        <p>
          Ghana <br />
          <strong>A Case Study in Strengthening Cyber Resilience ​</strong>{" "}
          <br />
          World Bank
        </p>
      ),
      buttonText: "Case study",
      link: "https://documents1.worldbank.org/curated/en/099111623162584046/pdf/P17785201f69be0150909902c3a7202107e.pdf",
      content: (
        <p>
          The case of Ghana demonstrates that forward-looking investments and
          policy initiatives based on international best-practices can go a long
          way in boosting cybersecurity capacity in developing countries.
        </p>
      ),
    },
    {
      rId: 223,
      image:
        "images/qii4/ManagingCyberSecurityRisks/Cybersecurity Assessment Toolkit for Smart Cities.png",
      title: (
        <p>
          Global <br />
          <strong>Cybersecurity Assessment Toolkit for Smart Cities</strong>
        </p>
      ),
      buttonText: "Guidance note",
      link: null,
      content: (
        <p>
          The Cybersecurity Assessment Toolkit guides countries and sectors to
          assess, strengthen, and mainstream cyber resilience in critical
          infrastructure.
        </p>
      ),
    },
    {
      rId: 122,
      image:
        "images/qii4/ManagingCyberSecurityRisks/UK The Cyber Assessment Framework (CAF) (National Cyber.png",
      title: (
        <p>
          United Kingdom <br />
          <strong>The Cyber Assessment Framework</strong> <br /> National Cyber
          Security Center
        </p>
      ),
      buttonText: "Framework",
      link: "https://www.ncsc.gov.uk/collection/cyber-assessment-framework/introduction-to-caf#section_1",
      content: (
        <p>
          This Cyber Assessment Framework (CAF) provides a systematic approach
          to assessing cyber risks and how they are being managed by the UK
          National Cyber Security Center.
        </p>
      ),
    },
    {
      rId: 151,
      image:
        "images/qii4/ManagingCyberSecurityRisks/Sectoral Cybersecurity Maturity Model (World Bank).jpg",
      title: (
        <p>
          Global <br />
          <strong>Sectoral Cybersecurity Maturity Model</strong> <br />
          World Bank
        </p>
      ),
      buttonText: "Guidance note",
      link: "https://documentsinternal.worldbank.org/Search/34392134",
      content: (
        <p>
          The Sectoral Cybersecurity Maturity Model evaluates cybersecurity
          maturity and provides actionable recommendations to strengthen cyber
          resilience, address vulnerabilities, and guide investment and policy
          decisions.
        </p>
      ),
    },
    {
      rId: 96,
      image:
        "images/qii4/ManagingCyberSecurityRisks/Cybersecurity Economics for Emerging Markets (World Bank).png",
      title: (
        <p>
          Global <br />
          <strong>Cybersecurity Economics for Emerging Markets</strong> <br />
          World Bank
        </p>
      ),
      buttonText: "Report",
      link: "https://documentsinternal.worldbank.org/Search/34392134",
      content: (
        <p>
          This report explores global cybersecurity threats and their impacts;
          the market failures that hinder responses; and proposes strategies,
          policies, and governance efforts to foster innovation and
          sustainability amid change and uncertainty. See page 87 onwards for a
          specific discussion on infrastructure.
        </p>
      ),
    },
  ];

  const step2Cards = [
    {
      rId: 129,
      image:
        "images/qii4/ManagingCyberSecurityRisks/Cybersecurity best practice for smart cities (CISA).png",
      title: (
        <p>
          Global <br />
          <strong>Cybersecurity Best Practice for Smart Cities ​</strong> <br />
          CISA
        </p>
      ),
      buttonText: "Guidance note",
      link: "https://www.cisa.gov/sites/default/files/2023-04/cybersecurity-best-practices-for-smart-cities_508.pdf",
      content: (
        <p>
          This document provides a useful introduction to the nature of
          cybersecurity threats and the motivations and strategies of malicious
          actors.
        </p>
      ),
    },
    {
      rId: 130,
      image: "images/qii4/updated/The-cyber-threat-environment.png",
      title: (
        <p>
          Canada <br />
          <strong>The Cyber Threat Environment</strong>
          <br />
          Government of Canada
        </p>
      ),
      buttonText: "Guidance note",
      link: "https://www.cyber.gc.ca/en/guidance/introduction-cyber-threat-environment",
      content: (
        <p>
          This document provides a useful introduction to the nature of
          cybersecurity threats and the motivations and strategies of malicious
          actors.
        </p>
      ),
    },
  ];

  useEffect(() => {
    setTimeout(() => {
      if (location.state?.scrollTo) {
        const el = document.getElementById(location.state.scrollTo);
        el?.scrollIntoView({ behavior: "smooth" });
        navigate(location.pathname, { replace: true, state: null });
      }
    }, 500);
  }, [location]);

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      setBradcrump({
        show: true,
        dir: [
          { path: "/qii4", title: "QII.4 Resilience" },
          {
            path: "/Managing-cyber-security-risks",
            title: "Managing Cybersecurity Risks",
          },
        ],
      }),
    );
  }, []);
  return (
    <div className="ManagingCyberSecurityRisks ResilientDesignAndOperation">
      <section className="color-light">
        <Header3
        id="qii4-MCR-section1"
          img="images/qii4/cybersecurity.png"
          title={"Managing Cybersecurity Risks"}
          hideDeskTitle={true}
        >
          <div className="hero-content">
            <div className="header-3-subpages">
              <img
                src="images/UpdatedAssets/Qii4.svg"
                alt="Qii4 logo"
                className="qii-badge"
              />
              <h1 className="header-title desk-title">
                Managing Cybersecurity Risks
              </h1>
            </div>
          </div>
          <div className="subpage-description">
            <p className="light-font">
              As economies and societies become increasingly digital,
              cybersecurity risks are rising in tandem. Essential infrastructure
              services—such as energy and transport networks—now rely on
              interconnected digital systems and technologies that increase
              their exposure to cyber threats.
              <br />
              <br />
              Strengthening cybersecurity is therefore fundamental to
              infrastructure resilience. The QII Partnership is at the forefront
              of integrating cybersecurity into infrastructure design and
              investment, working with governments and partners to assess risks,
              build capacity, and mainstream cyber resilience to ensure that
              critical infrastructure systems remain safe, trusted, and
              future-ready.
            </p>
          </div>
        </Header3>
        {/* <HeaderCarousal slidesData={slidesData}></HeaderCarousal> */}
        <div className="container internal-pages-container">
          <p className="link-text" id="qii4-MCR-section2">
            <strong>
              {" "}
              The following resources provide more details on the key
              interventions needed to systematically build cybersecurity into
              infrastructure planning, design and operations:
            </strong>
          </p>
          <NumSteps num="1" id="qii4-MCR-section2">
            <strong>Building a Foundation for Cybersecurity </strong> <br />
            This includes assessing cybersecurity maturity, developing
            strategies and legal frameworks, establishing cybersecurity
            governance structures, and strengthening institutions for
            implementation.
          </NumSteps>
          <VCardsPagination cardsData={step1Cards} id="qii4-MCR-section3"/>

          <div className="border-dash"></div>
          <NumSteps num="2" id="qii4-MCR-section4">
            <strong>Implementing Cyber Security in Practice </strong> <br />
            This involves evaluating critical cybersecurity risks and putting
            practical measures in place to manage and lower these risks.
          </NumSteps>
          <VCardsPagination cardsData={step2Cards} id="qii4-MCR-section5"/>
         
        </div>
      </section>
      {/* <section className="color-dark z-2" id="resourcesSection">
        <ResourceLibrary
          preSelected={[
            {
              show: true,
              category: "QII Principle",
              title: "QII.4 Resilience",
              id: 3,
            },
          ]}
        ></ResourceLibrary>
      </section> */}
    </div>
  );
}
