import React, { useEffect } from "react";
import "./Procurement.css";
import "./InternalPages.css";
import Header3 from "../components/Header3";
import NumSteps from "../components/NUmSteps";
import VCard from "../components/VCard";
import VCardsPagination from "../components/VCardsPagination";
import HeaderCarousal from "../components/HeaderCarousal";
import { useDispatch } from "react-redux";
import { setBradcrump } from "../slices/appDataSlice";
import ResourceLibrary from "./ResourceLibrary";
import { Popover, Tooltip } from "antd";
import { updateCardClick } from "../utils/cardRanking";
import { useLocation } from "react-router-dom";

export default function Procurement() {
  const location = useLocation(); 
  const resourceArray = [
    {
      rId: 8,
      id: 0,
      // country: "Global",
      title: "Global: Life-Cycle Cost Analysis Primer",
      // subTitle: "U.S. Department of Transportation - Federal Highway Administration",
      type: "Report",
      description:
        "This primer provides an introduction to LCCA as a method for comparing the total long-term costs, including agency and user costs, of alternative infrastructure project designs. It explains the step-by-step LCCA process, key concepts, and practical implementation issues.",
      img_path: "images/procurement/resources/01.png",
      path: "https://www.fhwa.dot.gov/pavement/lcca/010621.pdf",
    },

    {
      rId: 32,
      id: 1,
      // country: "Global",
      title:
        "Global: New Strategies for Strengthening Infrastructure Resilience and Maintenance ",
      // subTitle: "Organization for Economic Co-operation and Development",
      type: "Report",
      description:
        "This report presents strategies and practical recommendations for strengthening infrastructure resilience and maintenance, emphasizing a holistic, life-cycle approach. It covers regulatory frameworks, innovation (including digital and nature-based solutions), and funding models to help governments optimize existing assets and build new, sustainable infrastructure resilient to future risk.",
      img_path: "images/procurement/resources/02.png",
      path: "https://www.oecd.org/en/publications/building-resilience_354aa2aa-en.html",
    },
    {
      rId: 33,
      id: 2,
      // country: "Global",
      title: "Global: Bringing PPPs into the Sunlight",
      // subTitle: "Inter-American Development Bank",
      type: "Report",
      description:
        "This report critically examines Public-Private Partnerships (PPPs), considering their benefits and drawbacks. It provides guidance on institutional frameworks, fiscal implications, government support, and unsolicited proposals, emphasizing rigorous value-for-money analysis and risk management to avoid common pitfalls and maximize public benefit.",
      img_path: "images/procurement/resources/03.png",
      path: "https://publications.iadb.org/en/bringing-ppps-sunlight-synergies-now-and-pitfalls-later",
    },
    {
      id: 3,
      rId: 31,
      // country: "Global",
      title:
        "Global: Well Maintained: Economic Benefits from More Reliable and Resilient Infrastructure",
      // subTitle: "World Bank",
      type: "Report",
      description:
        "This report demonstrates that regular maintenance is essential for reliable and resilient infrastructure, quantifies the high economic and social costs of unreliable services, and provides evidence-based recommendations for improving maintenance practices, governance, and investment planning to maximize infrastructure’s economic benefits and resilience to shocks.",
      img_path: "images/procurement/resources/04.png",
      path: "https://ppp.worldbank.org/public-private-partnership/sites/default/files/2022-03/Final-LOW_WB_G20_Report_v4_1JUN_2021.pdf",
    },
    {
      id: 4,
      rId: 34,
      // country: "Global",
      title: "Global: Life-Cycle Costing in Sustainable Public Procurement",
      type: "Report",
      // subTitle: "International Institute for Sustainable Development",
      description:
        "This white paper explores how life-cycle costing (LCC) can enhance sustainable public procurement by evaluating all costs, financial, environmental, and social, across an asset’s life. It reviews global practices, highlights barriers to systematic LCC use, and offers recommendations for integrating LCC into procurement policies to achieve better long-term value and sustainability outcomes.",
      img_path: "images/procurement/resources/05.png",
      path: "https://www.iisd.org/publications/report/life-cycle-costing-sustainable-public-procurement-question-value",
    },
    {
      id: 4,
      rId: 224,
      // country: "Global",
      title: "Global: Sustainable Procurement Resource Hub",
      type: "Data",
      // subTitle: "International Institute for Sustainable Development",
      description:
        "This platform is a joint initiative by multilateral development bank (MDB) partners to create the one-stop online database to access and share knowledge on the latest advances in sustainable public procurement.",
      img_path: "images/qii2/Sustainable_Procurement_Resource_Hub.png",
      path: "https://www.sppresourcehub.org/",
    },
    {
      id: 4,
      rId: 225,
      // country: "Global",
      title: "Global: Value for Money in Procurement Financed by Multilateral Development Banks An Assessment Framework",
      type: "Framework",
      // subTitle: "International Institute for Sustainable Development",
      description:
        "This platform is a joint initiative by multilateral development bank (MDB) partners to create the one-stop online database to access and share knowledge on the latest advances in sustainable public procurement.",
      img_path: "images/qii2/qii2_promote.png",
      path: "https://www.adb.org/publications/value-for-money-procurement-mdbs",
    },
  ];


  const STEP1_PAGE_SIZE = 3;
  const step1Cards = [
    {
      image: "images/procurement/IndiaGanga.png",
      title: (
        <p>
          India <br />
          <strong>Ganga River Wastewater Program</strong>
          <br />
          World Bank
        </p>
      ),
      buttonText: "Full Publication​",
      link: "pdf/Ganga_case_study.pdf",
      buttonText2: "Case Study",
      link2:
        "https://www.gihub.org/innovative-funding-and-financing/case-studies/clean-ganga-program/",
      highlight: 1,
      rId: 16,
      content: (
        <p>
          Summarizes a procurement approach where annuity payments were linked
          to long-term O&M performance.
        </p>
      ),
    },

    {
      image: "images/procurement/Vietnam.png",
      title: (
        <p>
          Vietnam <br />
          <strong>Ho Chi Minh City PBCs</strong>
          <br />
          World Bank
        </p>
      ),
      rId: 15,
      buttonText: "Case Study",
      link: "https://www.ppiaf.org/documents/5629",
      content: (
        <p>
          Demonstrates the use of Performance-Based Contracts to incentivize
          non-revenue water reduction.
        </p>
      ),
    },
    {
      image: "images/procurement/ReferenceGuide.png",
      title: (
        <p>
          Global <br />
          <strong>
            Reference Guide on Output Specifications for Quality Infrastructure
          </strong>
          <br />
          Global Infrastructure Hub
        </p>
      ),
      rId: 43,
      buttonText: "Guidance note",
      link: "https://www.gihub.org/infrastructure-output-specifications/",
      content: (
        <p>
          Provides guidance on how quality infrastructure is incorporated in
          output specifications of long-term infrastructure contracts.
        </p>
      ),
    },
  ];

  const step2Cards = [
    {
      image: "images/procurement/Pre-Fabrication.png",
      title: (
        <p>
          Global <br />
          <strong>Pre-Fabrication Technology for Modular Construction</strong>
          <br />
          Global Infrastructure Hub
        </p>
      ),
      rId: 17,
      buttonText: "Case Study",
      link: "https://www.gihub.org/infrastructure-technology-use-cases/case-studies/pre-fabrication-technology-for-modular-construction/",
      content: (
        <p>
          Reduces the cost and time taken to construct infrastructure projects
          by using pre-fabricated and modular components of railways and road
          bridges.
        </p>
      ),
    },
    {
      image: "images/procurement/Disruptive.png",
      title: (
        <p>
          Global <br />
          <strong>Disruptive Technologies in Public Procurement</strong>
          <br />
          World Bank
        </p>
      ),
      rId: 30,
      buttonText: "Report",
      link: "https://documents.worldbank.org/en/publication/documents-reports/documentdetail/522181612428427520/disruptive-technologies-in-public-procurement",
      content: (
        <p>
          Provides guidance on how to integrate the use of technologies in
          public procurement to enhance value-for-money and reduce total cost of
          ownership.
        </p>
      ),
    },
  ];

    useEffect(() => {
      setTimeout(() => {
        if (location.state?.scrollTo) {
          const el = document.getElementById(location.state.scrollTo);
          el?.scrollIntoView({ behavior: "smooth" });
          navigate(location.pathname, { replace: true, state: null });
        }
      }, 500);
    }, [location]);

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      setBradcrump({
        show: true,
        dir: [
          { path: "/qii2", title: "QII.2 Economic Efficiency" },
          { path: "/procurement", title: "Procurement" }, 
        ],
      }),
    );
  }, []);
  return (
    <div className="procurement">
      <section className="color-light">
        {/* <HeaderCarousal slidesData={slidesData}></HeaderCarousal> */}

        {/* <div className="container noPTop">
          <div className="link-text">
            <strong>
              Key procurement considerations to maximize economic efficiency
              include:{" "}
            </strong>
          </div> */}
        <Header3
          id="qii2-procurement-section1"
          img="images/procurement/header_bg_1.png"
          title={"Procurement"}
          hideDeskTitle={true}
        >
          <div className="hero-content">
            <div className="header-3-subpages">
              <img
                src="images/UpdatedAssets/Qii2.svg"
                alt="Qii2 logo"
                className="qii-badge"
              />
              <h1 className="header-title desk-title">Procurement</h1>
            </div>
          </div>
          <div className="subpage-description">
            <p className="light-font">
              The procurement process sets the foundation for the economic
              efficiency of an infrastructure project. Procurement processes
              that create incentives to minimize life- cycle costs lead to
              better value for money and reduce long-term expenses. Conversely,
              weak procurement practices, such as focusing solely on initial
              purchase price, can result in higher operational and maintenance
              costs over the asset's lifespan.
            </p>
          </div>
        </Header3>
        <div className="container internal-pages-container">
          <div className="link-text" id="qii2-procurement-section2">
            <p>
              <strong>Spotlight on PPPs</strong>
            </p>
            <p className="mTop">
              The procurement of infrastructure under Public- Private
              Partnerships (PPPs) can be an effective way to align incentives
              for cost efficiency over the course of the project. This alignment
              will be strongest under PPPs that include an extended Operations
              and Maintenance phase and where the revenues of the private sector
              partner are linked directly to long-term performance.
            </p>
            <p className="mTop">
              Such incentives may not be as strong for infrastructure projects
              using public procurement. However, in such cases, the evaluation
              criteria for construction contracts can still be structured to
              encourage bidders to factor life- cycle costing into the
              infrastructure design.
            </p>
            <div className="border-dash"></div>
            <p className="mTop">
              <strong>
                Key procurement considerations to maximize economic efficiency
                include:
              </strong>
            </p>
          </div>
          <div className="link-text mTop"></div>
          <NumSteps num="1" id="qii2-procurement-section3">
            <strong>Incentive Structures</strong>
            <br /> <br className="mobile-break" />
            Performance-Based Contracts (PBCs) can be used to link contractors’
            payments to long-term performance and efficiency.
          </NumSteps>
          <VCardsPagination
            cardsData={step1Cards}
            id="qii2-procurement-section3"
          />
          {/* <div className="VCard-cnt col3">
            <VCard
              image="images/procurement/IndiaGanga.png"
              title={
                <p>
                  India <br />
                  <strong>Ganga River Wastewater Program</strong> <br />
                  World Bank
                </p>
              }
              buttonText="View the full publication​"
              link2="https://www.gihub.org/innovative-funding-and-financing/case-studies/clean-ganga-program/"
              buttonText2="Case Study"
              link="pdf/Ganga_case_study.pdf"
              highlight={2}
            >
              <p>
                Summarizes a procurement approach for a real-life project where
                annuity payments were linked to long-term O&M performance.
              </p>
            </VCard>
            <VCard
              image="images/procurement/Vietnam.png"
              title={
                <p>
                  Vietnam
                  <br />
                  <strong> Ho Chi Minh City PBCs </strong>
                  <br />
                  World Bank
                </p>
              }
              buttonText="Case Study"
              link="https://www.ppiaf.org/documents/5629"
            >
              <p>
                Demonstrates the use of Performance-Based Contracts (PBC) to
                incentivize non-revenue water reduction.
              </p>
            </VCard>

            <VCard
              image="images/procurement/ReferenceGuide.png"
              title={
                <p>
                  <strong>
                    Reference Guide on Output Specifications for Quality
                    Infrastructure
                  </strong>{" "}
                  <br />
                  Global Infrastructure Hub
                </p>
              }
              buttonText="Guidance"
              link="https://www.gihub.org/infrastructure-output-specifications/"
            >
              <p>
                Provides guidance on how quality infrastructure is incorporated
                in output specifications of long-term infrastructure contracts.
              </p>
            </VCard>
          </div> */}
          <div className="border-dash"></div>
          <NumSteps num="2" id="qii2-procurement-section4">
            <strong>Innovative Technologies</strong>
            <br /> <br className="mobile-break" />
            Procurement processes can incentivize the adoption of innovative
            technologies to enable cost saving during construction and O&M.
          </NumSteps>
          <VCardsPagination
            cardsData={step2Cards}
            id="qii2-procurement-section4"
          />
          {/* <div className="VCard-cnt col-2">
            <VCard
              image="images/procurement/Pre-Fabrication.png"
              title={
                <p>
                  <strong>
                    Pre-Fabrication Technology for Modular Construction
                  </strong>{" "}
                  <br />
                  Global Infrastructure Hub
                </p>
              }
              buttonText="Case Study"
              link="https://www.gihub.org/infrastructure-technology-use-cases/case-studies/pre-fabrication-technology-for-modular-construction/"
            >
              <p>
                Reduces the cost and time taken to construct infrastructure
                projects by using pre-fabricated and modular components of
                railways and road bridges.
              </p>
            </VCard>

            <VCard
              image="images/procurement/Disruptive.png"
              title={
                <p>
                  <strong>Disruptive Technologies in Public Procurement</strong>{" "}
                  <br />
                  World Bank
                </p>
              }
              buttonText="Case Study"
              link="https://documents.worldbank.org/en/publication/documents-reports/documentdetail/522181612428427520/disruptive-technologies-in-public-procurement"
            >
              <p>
                Provides guidance on how to integrate the use of technologies in
                public procurement to enhance value-for-money and reduce total
                cost of ownership.
              </p>
            </VCard>
          </div> */}
        </div>
      </section>
      <section className="color-dark" id="qii2-procurement-section5">
        <div className="container internal-pages-container">
          <h2 className="section-title light-font">
            Further Reading On Procurement
          </h2>
          <div className="page-resource-grid" role="list">
            {resourceArray.map((p, index) => (
              <article
                className="page-resource-card"
                key={index}
                role="listitem"
                style={{ backgroundImage: `url(${p.img})` }}
              >
                <div className="page-resource-link">
                  <div className="page-resource-body">
                    <div className="page-resource-title title-small">
                      <p className="page-resource-type">{p.type}</p>
                      {/* {p.country && (
                        <>
                          <span>{p.country}</span> <br />
                        </>
                      )} */}
                      {/* <strong>{p.title}</strong> */}
                      <br />
                      {p.title}
                      {/* {p.org && (
                        <>
                          <br />
                          <span>{p.org}</span>
                        </>
                      )} */}
                      {/* {p.subTitle && (
                        <>
                          <br />
                          <span>{p.subTitle}</span>
                        </>
                      )} */}
                    </div>
                    <div className="page-resource-overlay" />
                    <img
                      className="page-resource-img"
                      src={p.img_path}
                      alt={p.title}
                    />
                    {/* <div className="page-resource-img-cnt">
                    </div> */}
                    <div className="page-resource-data">
                      <div className="page-resource-title title-big">
                        <p className="page-resource-type">{p.type}</p>
                        {/* {p.country && (
                          <>
                            <span>{p.country}</span> <br />
                          </>
                        )} */}
                        {/* <strong>{p.title}</strong> */}
                        <br />
                        {p.title}
                        {/* {p.org && (
                          <>
                            <br />
                            <span>{p.org}</span>
                          </>
                        )} */}
                        {/* {p.subTitle && (
                          <>
                            <br />
                            <span>{p.subTitle}</span>
                          </>
                        )} */}
                      </div>
                      {/* <div className="page-resource-description">
                        {p.description}
                      </div> */}
                      {/* <Popover
                        content={p.description}
                        // title={p.title}
                        trigger="click"
                      >
                        <div className="page-resource-description">
                          Read More...
                        </div>
                      </Popover> */}
                      <Popover
                        content={
                          <div className="resource-popover-content">
                            {p.description}
                          </div>
                        }
                        placement="left"
                        title={false}
                        trigger="click"
                      >
                        <div className="page-resource-description">
                          Read More...
                        </div>
                      </Popover>
                      <div className="page-resource-btn-cnt">
                        <a
                          className="page-resource-arrow"
                          href={p.path}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => {
                            e.preventDefault();
                            updateCardClick(p.rId);

                            if (p.path) {
                              window.open(p.path, "_blank");
                            }
                          }}
                        >
                          <span className="icon-arrow">&#xe900;</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      {/* <section className="color-light z-2" id="resourcesSection">
        <ResourceLibrary
          preSelected={[
            {
              show: true,
              category: "QII Principle",
              title: "QII.2 Economic Efficiency",
              id: 1,
            },
          ]}
        ></ResourceLibrary>
      </section> */}
    </div>
  );
}
